

public enum MoveMode
    {
        Move,
        Running,
        Slow,
        Idle,
    }
